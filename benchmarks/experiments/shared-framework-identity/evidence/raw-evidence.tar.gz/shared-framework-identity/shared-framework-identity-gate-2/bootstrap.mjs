import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
if (createHash('sha256').update(readFileSync("/root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/benchmarks/experiments/shared-framework-identity/loader.mjs")).digest('hex') !== "e81600208753c0fabae75bd8798ef55f8490df6cb8290820292963bea79ffef4") throw Error('Loader source override');
const { register } = await import("file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/benchmarks/experiments/shared-framework-identity/loader.mjs");
register("/tmp/shared-framework-identity-build-2/build.json","cc232a3cd8d9fb5a4459d7a7c55bec8b90b259c227ab0f26badcee24c3bf7898","/tmp/shared-framework-identity-gate-2/trace-"+process.pid+'.jsonl');
await import("file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/workers/forks.js");
globalThis.__nativeIdentityHelper=await import("file:///tmp/shared-framework-identity-gate-2/native-helper.mjs");
globalThis.__bootstrapIdentity={api:await import("file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/index.js"),owner:await import("file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/index.CZzC1gGg.js"),collector:await import("file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/run.CjdgFZiW.js"),spy:await import("file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/spy.DDMXghXv.js")};
