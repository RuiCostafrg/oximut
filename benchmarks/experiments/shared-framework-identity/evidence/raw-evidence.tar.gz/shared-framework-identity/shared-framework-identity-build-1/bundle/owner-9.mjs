import "./shared-CPxUEhZH.mjs";
import { g as getWorkerState } from "./owner-23.mjs";
import { t as takeCoverageInsideWorker } from "./owner-3.mjs";
import { r as rpc } from "./owner-18.mjs";
import { T as TestRunner } from "./owner-6.mjs";
import { a as loadSnapshotSerializers, l as loadDiffConfig } from "./owner-20.mjs";
import * as chai from "file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/chai/index.js";
import { createHook } from "node:async_hooks";
// node_modules/vitest/dist/chunks/index.w_oBZ9N8.js
globalThis.__sharedEvaluations ??= {};
globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/index.w_oBZ9N8.js"] = (globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/index.w_oBZ9N8.js"] || 0) + 1;
function setupChaiConfig(config) {
	Object.assign(chai.config, config);
}
async function resolveSnapshotEnvironment(config, moduleRunner) {
	if (!config.snapshotEnvironment) {
		const { VitestNodeSnapshotEnvironment } = await import("./owner-13.mjs");
		return new VitestNodeSnapshotEnvironment();
	}
	const mod = await moduleRunner.import(config.snapshotEnvironment);
	if (typeof mod.default !== "object" || !mod.default) throw new Error("Snapshot environment module must have a default export object with a shape of `SnapshotEnvironment`");
	return mod.default;
}
const IGNORED_TYPES = /* @__PURE__ */ new Set([
	"DNSCHANNEL",
	"ELDHISTOGRAM",
	"PerformanceObserver",
	"RANDOMBYTESREQUEST",
	"SIGNREQUEST",
	"STREAM_END_OF_STREAM",
	"TCPWRAP",
	"TIMERWRAP",
	"TLSWRAP",
	"ZLIB"
]);
const STDIO_TYPES = /* @__PURE__ */ new Set(["PIPEWRAP", "TTYWRAP"]);
function detectAsyncLeaks(testFile, projectName) {
	const resources = /* @__PURE__ */ new Map();
	const hook = createHook({
		init(asyncId, type, triggerAsyncId, resource) {
			if (IGNORED_TYPES.has(type)) return;
			let stack = "";
			const limit = Error.stackTraceLimit;
			try {
				Error.stackTraceLimit = 100;
				stack = (/* @__PURE__ */ new Error("VITEST_DETECT_ASYNC_LEAKS")).stack || "";
			} catch {
				return;
			} finally {
				Error.stackTraceLimit = limit;
			}
			if (stack.includes("node:internal/bootstrap/realm")) return;
			if (!stack.includes(testFile)) {
				const trigger = resources.get(triggerAsyncId);
				if (!trigger) return;
				stack = trigger.stack;
			}
			let isActive = isActiveDefault;
			if ("hasRef" in resource) {
				const ref = new WeakRef(resource);
				isActive = () => ref.deref()?.hasRef() ?? false;
			}
			resources.set(asyncId, {
				type,
				stack,
				projectName,
				filename: testFile,
				isActive,
				handle: STDIO_TYPES.has(type) ? new WeakRef(resource) : void 0
			});
		},
		destroy(asyncId) {
			if (resources.get(asyncId)?.type !== "PROMISE") resources.delete(asyncId);
		},
		promiseResolve(asyncId) {
			resources.delete(asyncId);
		}
	});
	hook.enable();
	return async function collect() {
		await new Promise((resolve) => setImmediate(resolve));
		hook.disable();
		const leaks = [];
		for (const resource of resources.values()) if (resource.isActive() && !isStdioHandle(resource.handle?.deref())) leaks.push({
			stack: resource.stack,
			type: resource.type,
			filename: resource.filename,
			projectName: resource.projectName
		});
		resources.clear();
		return leaks;
	};
}
function isActiveDefault() {
	return true;
}
function isStdioHandle(handle) {
	if (!handle) return false;
	return [
		process.stdin,
		process.stdout,
		process.stderr
	].some((stream) => stream._handle === handle);
}
async function getTestRunnerConstructor(config, moduleRunner) {
	if (!config.runner) return TestRunner;
	const mod = await moduleRunner.import(config.runner);
	if (!mod.default && typeof mod.default !== "function") throw new Error(`Runner must export a default function, but got ${typeof mod.default} imported from ${config.runner}`);
	return mod.default;
}
async function resolveTestRunner(config, moduleRunner, traces) {
	const testRunner = new (await (getTestRunnerConstructor(config, moduleRunner)))(config);
	Object.defineProperty(testRunner, "moduleRunner", {
		value: moduleRunner,
		enumerable: false,
		configurable: false
	});
	if (!testRunner.config) testRunner.config = config;
	if (!testRunner.importFile) throw new Error("Runner must implement \"importFile\" method.");
	if ("__setTraces" in testRunner) testRunner.__setTraces(traces);
	const [diffOptions] = await Promise.all([loadDiffConfig(config, moduleRunner), loadSnapshotSerializers(config, moduleRunner)]);
	testRunner.config._diffOptions = diffOptions;
	const originalOnTaskUpdate = testRunner.onTaskUpdate;
	testRunner.onTaskUpdate = async (task, events) => {
		const p = rpc().onTaskUpdate(task, events);
		await originalOnTaskUpdate?.call(testRunner, task, events);
		return p;
	};
	const originalOnTestAnnotate = testRunner.onTestAnnotate;
	testRunner.onTestAnnotate = async (test, annotation) => {
		const p = rpc().onTaskArtifactRecord(test.id, {
			type: "internal:annotation",
			location: annotation.location,
			annotation
		});
		const overriddenResult = await originalOnTestAnnotate?.call(testRunner, test, annotation);
		const vitestResult = await p;
		return overriddenResult || vitestResult.annotation;
	};
	const originalOnTestArtifactRecord = testRunner.onTestArtifactRecord;
	testRunner.onTestArtifactRecord = async (test, artifact) => {
		const p = rpc().onTaskArtifactRecord(test.id, artifact);
		const overriddenResult = await originalOnTestArtifactRecord?.call(testRunner, test, artifact);
		const vitestResult = await p;
		return overriddenResult || vitestResult;
	};
	const originalOnCollectStart = testRunner.onCollectStart;
	testRunner.onCollectStart = async (file) => {
		await rpc().onQueued(file);
		await originalOnCollectStart?.call(testRunner, file);
	};
	const originalOnCollected = testRunner.onCollected;
	testRunner.onCollected = async (files) => {
		const state = getWorkerState();
		files.forEach((file) => {
			file.prepareDuration = state.durations.prepare;
			file.environmentLoad = state.durations.environment;
			state.durations.prepare = 0;
			state.durations.environment = 0;
		});
		const sanitizeRetryConditions = (task) => {
			if (task.retry && typeof task.retry === "object" && typeof task.retry.condition === "function") task.retry = {
				...task.retry,
				condition: void 0
			};
			if (task.tasks) task.tasks.forEach(sanitizeRetryConditions);
		};
		files.forEach(sanitizeRetryConditions);
		rpc().onCollected(files);
		await originalOnCollected?.call(testRunner, files);
	};
	const originalOnAfterRun = testRunner.onAfterRunFiles;
	testRunner.onAfterRunFiles = async (files) => {
		const state = getWorkerState();
		const coverage = await takeCoverageInsideWorker(config.coverage, moduleRunner);
		if (coverage) rpc().onAfterSuiteRun({
			coverage,
			testFiles: files.map((file) => file.name).sort(),
			environment: state.environment.viteEnvironment || state.environment.name,
			projectName: state.ctx.projectName
		});
		await originalOnAfterRun?.call(testRunner, files);
	};
	const originalOnAfterRunTask = testRunner.onAfterRunTask;
	testRunner.onAfterRunTask = async (test) => {
		if (config.bail && test.result?.state === "fail") {
			if (1 + await rpc().getCountOfFailedTests() >= config.bail) {
				rpc().onCancel("test-failure");
				testRunner.cancel?.("test-failure");
			}
		}
		await originalOnAfterRunTask?.call(testRunner, test);
	};
	return testRunner;
}
export { resolveSnapshotEnvironment as a, detectAsyncLeaks as d, resolveTestRunner as r, setupChaiConfig as s };

//# sourceMappingURL=owner-9.mjs.map