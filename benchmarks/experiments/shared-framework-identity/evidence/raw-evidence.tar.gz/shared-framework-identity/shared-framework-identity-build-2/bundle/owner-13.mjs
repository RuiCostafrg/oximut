import "./shared-CPxUEhZH.mjs";
import { b as basename, d as dirname, i as isAbsolute, j as join, r as resolve } from "./owner-15.mjs";
import { g as getWorkerState } from "./owner-24.mjs";
import { existsSync, promises } from "node:fs";
// node_modules/vitest/dist/chunks/node.B9mkVmLH.js
globalThis.__sharedEvaluations ??= {};
globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/node.B9mkVmLH.js"] = (globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/node.B9mkVmLH.js"] || 0) + 1;
var NodeSnapshotEnvironment = class {
	options;
	constructor(options = {}) {
		this.options = options;
	}
	getVersion() {
		return "1";
	}
	getHeader() {
		return `// Snapshot v${this.getVersion()}`;
	}
	async resolveRawPath(testPath, rawPath) {
		return isAbsolute(rawPath) ? rawPath : resolve(dirname(testPath), rawPath);
	}
	async resolvePath(filepath) {
		return join(join(dirname(filepath), this.options.snapshotsDirName ?? "__snapshots__"), `${basename(filepath)}.snap`);
	}
	async prepareDirectory(dirPath) {
		await promises.mkdir(dirPath, { recursive: true });
	}
	async saveSnapshotFile(filepath, snapshot) {
		await promises.mkdir(dirname(filepath), { recursive: true });
		await promises.writeFile(filepath, snapshot, "utf-8");
	}
	async readSnapshotFile(filepath) {
		if (!existsSync(filepath)) return null;
		return promises.readFile(filepath, "utf-8");
	}
	async removeSnapshotFile(filepath) {
		if (existsSync(filepath)) await promises.unlink(filepath);
	}
};
var VitestNodeSnapshotEnvironment = class extends NodeSnapshotEnvironment {
	getHeader() {
		return `// Vitest Snapshot v${this.getVersion()}, https://vitest.dev/guide/snapshot.html`;
	}
	resolvePath(filepath) {
		return getWorkerState().rpc.resolveSnapshotPath(filepath);
	}
};
export { VitestNodeSnapshotEnvironment };

//# sourceMappingURL=owner-13.mjs.map