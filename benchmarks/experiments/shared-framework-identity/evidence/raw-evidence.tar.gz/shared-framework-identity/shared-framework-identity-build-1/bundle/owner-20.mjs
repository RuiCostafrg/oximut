import "./shared-CPxUEhZH.mjs";
import { s as setSafeTimers } from "./owner-21.mjs";
import { a as addSerializer } from "./owner-16.mjs";
// node_modules/vitest/dist/chunks/setup-common.CqAQCXzx.js
globalThis.__sharedEvaluations ??= {};
globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/setup-common.CqAQCXzx.js"] = (globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/setup-common.CqAQCXzx.js"] || 0) + 1;
let globalSetup = false;
async function setupCommonEnv(config) {
	setupDefines(config);
	if (globalSetup) return;
	globalSetup = true;
	setSafeTimers();
	if (config.globals) (await import("./owner-5.mjs")).registerApiGlobally();
}
function setupDefines(config) {
	for (const key in config.defines) globalThis[key] = config.defines[key];
}
function setupEnv(env, metaEnv) {
	for (const key in env) metaEnv[key] = env[key];
}
async function loadDiffConfig(config, moduleRunner) {
	if (typeof config.diff === "object") return config.diff;
	if (typeof config.diff !== "string") return;
	const diffModule = await moduleRunner.import(config.diff);
	if (diffModule && typeof diffModule.default === "object" && diffModule.default != null) return diffModule.default;
	else throw new Error(`invalid diff config file ${config.diff}. Must have a default export with config object`);
}
async function loadSnapshotSerializers(config, moduleRunner) {
	const files = config.snapshotSerializers;
	(await Promise.all(files.map(async (file) => {
		const mo = await moduleRunner.import(file);
		if (!mo || typeof mo.default !== "object" || mo.default === null) throw new Error(`invalid snapshot serializer file ${file}. Must export a default object`);
		const config = mo.default;
		if (typeof config.test !== "function" || typeof config.serialize !== "function" && typeof config.print !== "function") throw new TypeError(`invalid snapshot serializer in ${file}. Must have a 'test' method along with either a 'serialize' or 'print' method.`);
		return config;
	}))).forEach((serializer) => addSerializer(serializer));
}
export { loadSnapshotSerializers as a, setupEnv as b, loadDiffConfig as l, setupCommonEnv as s };

//# sourceMappingURL=owner-20.mjs.map