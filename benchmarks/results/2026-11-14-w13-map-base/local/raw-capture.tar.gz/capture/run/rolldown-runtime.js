import { createRequire } from 'node:module';
export var __create = Object.create;
export var __defProp = Object.defineProperty;
export var __name = (target, value) => __defProp(target, 'name', { value, configurable: true });
export var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
export var __getOwnPropNames = Object.getOwnPropertyNames;
export var __getProtoOf = Object.getPrototypeOf;
export var __hasOwnProp = Object.prototype.hasOwnProperty;
export var __esm = (fn, res, err) =>
  function () {
    if (err) throw err[0];
    try {
      return (fn && (res = (0, fn[__getOwnPropNames(fn)[0]])((fn = 0))), res);
    } catch (e) {
      throw ((err = [e]), e);
    }
  };
export var __esmMin = (fn, res, err) => () => {
  if (err) throw err[0];
  try {
    return (fn && (res = fn((fn = 0))), res);
  } catch (e) {
    throw ((err = [e]), e);
  }
};
export var __commonJS = (cb, mod) =>
  function () {
    return (
      mod || ((0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod, mod.exports), cb = null), mod.exports
    );
  };
export var __commonJSMin = (cb, mod) => () => (
  mod || (cb((mod = { exports: {} }).exports, mod, mod.exports), cb = null), mod.exports
);
export var __exportAll = (all, no_symbols) => {
  let target = {};
  for (var name in all) {
    __defProp(target, name, { get: all[name], enumerable: true });
  }
  if (!no_symbols) {
    __defProp(target, Symbol.toStringTag, { value: 'Module' });
  }
  return target;
};
export var __copyProps = (to, from, except, desc) => {
  if ((from && typeof from === 'object') || typeof from === 'function') {
    for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
      key = keys[i];
      if (!__hasOwnProp.call(to, key) && key !== except) {
        __defProp(to, key, {
          get: ((k) => from[k]).bind(null, key),
          enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable,
        });
      }
    }
  }
  return to;
};
export var __reExport = (target, mod, secondTarget) => (
  __copyProps(target, mod, 'default'), secondTarget && __copyProps(secondTarget, mod, 'default')
);
export var __toESM = (mod, isNodeMode, target) => (
  (target = mod != null ? __create(__getProtoOf(mod)) : {}),
  __copyProps(
    // `__esModule` alone is not enough: the module must own a `default` (#10360).
    isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, 'default')
      ? __defProp(target, 'default', { value: mod, enumerable: true })
      : target,
    mod,
  )
);
export var __toCommonJS = (mod) =>
  __hasOwnProp.call(mod, 'module.exports')
    ? mod['module.exports']
    : __copyProps(__defProp({}, '__esModule', { value: true }), mod);
// `__share*`: the registry behind `codeSplitting.experimentalInlineCommonChunks`. A chunk factory
// is registered under its record id by every file that carries it; the first registration wins,
// `__share_require` runs the winning factory once and hands every reader the same exports object.
// See internal-docs/inline-common-chunks/implementation.md.
export var __share_factories = /* @__PURE__ */ __create(null);
export var __share_records = /* @__PURE__ */ __create(null);
export var __share = (id, factory) => {
  if (!(id in __share_factories)) __share_factories[id] = factory;
};
export var __share_require = (id) => {
  var record = __share_records[id];
  if (record) {
    // A failed factory rethrows the same value on every read, including `undefined`; a factory
    // that is still running hands back its partially filled exports object.
    if (record.failed) throw record.error;
    return record.exports;
  }
  var factory = __share_factories[id];
  if (!factory) throw new Error('Shared chunk "' + id + '" was not registered before it was required.');
  record = __share_records[id] = { exports: {}, failed: false, error: void 0 };
  try {
    factory(record.exports);
  } catch (error) {
    record.failed = true;
    record.error = error;
    throw error;
  }
  return record.exports;
};
export var __share_export = (target, all) => {
  for (var name in all) __defProp(target, name, { get: all[name], enumerable: true });
};
export var __toBinaryNode = (base64) => new Uint8Array(Buffer.from(base64, 'base64'));
export var __toBinary = /* @__PURE__ */ (() => {
  var table = new Uint8Array(128);
  for (var i = 0; i < 64; i++) {
    table[i < 26 ? i + 65 : i < 52 ? i + 71 : i < 62 ? i - 4 : i * 4 - 205] = i;
  }
  return (base64) => {
    var n = base64.length,
      bytes = new Uint8Array((((n - (base64[n - 1] == '=') - (base64[n - 2] == '=')) * 3) / 4) | 0);
    for (var i = 0, j = 0; i < n; ) {
      var c0 = table[base64.charCodeAt(i++)],
        c1 = table[base64.charCodeAt(i++)];
      var c2 = table[base64.charCodeAt(i++)],
        c3 = table[base64.charCodeAt(i++)];
      bytes[j++] = (c0 << 2) | (c1 >> 4);
      bytes[j++] = (c1 << 4) | (c2 >> 2);
      bytes[j++] = (c2 << 6) | c3;
    }
    return bytes;
  };
})();
// This is created by the rolldown. It's used to polyfill the global `require` function when you bundling code
// with target `format: 'es'` and `platform: 'node'`. It's used to make sure the global `require` could
// works in Node.js esm environment.
export var __require = /* #__PURE__ */ (() => createRequire(import.meta.url))();
