import "./shared-CPxUEhZH.mjs";
import { i } from "file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/init.CO4AB7HZ.js";
// node_modules/vitest/dist/chunks/init-forks.BaDXQSD8.js
globalThis.__sharedEvaluations ??= {};
globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/init-forks.BaDXQSD8.js"] = (globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/init-forks.BaDXQSD8.js"] || 0) + 1;
if (!process.send) throw new Error("Expected worker to be run in node:child_process");
const processExit = process.exit.bind(process);
const processSend = process.send.bind(process);
const processOn = process.on.bind(process);
const processOff = process.off.bind(process);
const processRemoveAllListeners = process.removeAllListeners.bind(process);
if (process.execArgv.some((execArg) => execArg.startsWith("--prof") || execArg.startsWith("--cpu-prof") || execArg.startsWith("--heap-prof") || execArg.startsWith("--diagnostic-dir"))) processOn("SIGTERM", () => processExit());
processOn("error", onError);
function workerInit(options) {
	const { runTests } = options;
	i({
		post: (v) => processSend(v),
		on: (cb) => processOn("message", cb),
		off: (cb) => processOff("message", cb),
		teardown: () => {
			processRemoveAllListeners("message");
			processOff("error", onError);
			process.exit = processExit;
		},
		runTests: (state, traces) => runTests("run", state, traces),
		collectTests: (state, traces) => runTests("collect", state, traces),
		setup: options.setup
	});
}
function onError(error) {
	if (error?.code === "ERR_IPC_CHANNEL_CLOSED" || error?.code === "EPIPE") processExit(1);
}
export { workerInit as w };

//# sourceMappingURL=owner-10.mjs.map