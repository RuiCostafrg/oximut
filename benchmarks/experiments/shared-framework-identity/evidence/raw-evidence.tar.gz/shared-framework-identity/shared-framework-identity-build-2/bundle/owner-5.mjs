import "./shared-CPxUEhZH.mjs";
import "./owner-23.mjs";
import "./owner-7.mjs";
import "./owner-15.mjs";
import "./owner-21.mjs";
import "./owner-24.mjs";
import { g as globalApis } from "./owner-2.mjs";
import "./owner-4.mjs";
import "./owner-26.mjs";
import "./owner-19.mjs";
import "./owner-22.mjs";
import "./owner-16.mjs";
import "./owner-14.mjs";
import "./owner-17.mjs";
import "./owner-8.mjs";
import "./owner-18.mjs";
import { i as index } from "./owner-6.mjs";
import "file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/chai/index.js";
import "file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vite/dist/node/module-runner.js";
import "file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/tinybench/dist/index.js";
import "file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/expect-type/dist/index.js";
// node_modules/vitest/dist/chunks/globals.ZKtKSkEf.js
globalThis.__sharedEvaluations ??= {};
globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/globals.ZKtKSkEf.js"] = (globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/globals.ZKtKSkEf.js"] || 0) + 1;
function registerApiGlobally() {
	globalApis.forEach((api) => {
		globalThis[api] = index[api];
	});
}
export { registerApiGlobally };

//# sourceMappingURL=owner-5.mjs.map