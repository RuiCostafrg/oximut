import "./shared-CPxUEhZH.mjs";
import { r } from "file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/coverage.jGCktcGP.js";
// node_modules/vitest/dist/chunks/coverage.9iqXE2gN.js
globalThis.__sharedEvaluations ??= {};
globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/coverage.9iqXE2gN.js"] = (globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/coverage.9iqXE2gN.js"] || 0) + 1;
async function startCoverageInsideWorker(options, loader, runtimeOptions) {
	const coverageModule = await r(options, loader);
	if (coverageModule) return coverageModule.startCoverage?.({
		...runtimeOptions,
		autoAttachSubprocess: options.autoAttachSubprocess,
		reportsDirectory: options.reportsDirectory
	});
	return null;
}
async function takeCoverageInsideWorker(options, loader) {
	const coverageModule = await r(options, loader);
	if (coverageModule) return coverageModule.takeCoverage?.({
		moduleExecutionInfo: loader.moduleExecutionInfo,
		coverageFilesDirectory: options.coverageFilesDirectory
	});
	return null;
}
async function stopCoverageInsideWorker(options, loader, runtimeOptions) {
	const coverageModule = await r(options, loader);
	if (coverageModule) return coverageModule.stopCoverage?.(runtimeOptions);
	return null;
}
export { stopCoverageInsideWorker as a, startCoverageInsideWorker as s, takeCoverageInsideWorker as t };

//# sourceMappingURL=owner-3.mjs.map