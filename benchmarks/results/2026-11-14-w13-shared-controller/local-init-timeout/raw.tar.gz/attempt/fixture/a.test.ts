import {test,expect} from 'vitest';
import {randomUUID} from 'node:crypto'; import {appendFileSync} from 'node:fs';
import {active,count,add,multiply} from './subject';
appendFileSync("/tmp/w13-integration-M5sVhh/fixture-events.jsonl",JSON.stringify({pid:process.pid,realm:randomUUID(),active})+'\n');
test('state and bootstrap URI',()=>{expect(count()).toBe(0);try{process.exit(7)}catch(e){expect(e.stack).toContain('file://'+"/root/.t3/worktrees/oximut/t3-8d8fd2c8-76fe618371a29e13/node_modules/vitest/dist/chunks/base.Cof-UHJf.js"+':123:9');appendFileSync("/tmp/w13-integration-M5sVhh/stacks.jsonl",JSON.stringify({pid:process.pid,stack:e.stack})+'\n')}});
test('add',()=>expect(add()).toBe(3)); test('multiply',()=>expect(multiply()).toBe(6));
test('deadline',()=>{if(active==='hang')while(true){};expect(true).toBe(true)});