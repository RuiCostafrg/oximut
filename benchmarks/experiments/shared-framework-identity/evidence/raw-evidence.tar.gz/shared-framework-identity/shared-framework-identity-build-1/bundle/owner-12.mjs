import "./shared-CPxUEhZH.mjs";
import { builtinModules } from "node:module";
// node_modules/vitest/dist/chunks/modules.BJuCwlRJ.js
globalThis.__sharedEvaluations ??= {};
globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/modules.BJuCwlRJ.js"] = (globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/modules.BJuCwlRJ.js"] || 0) + 1;
const NODE_BUILTIN_NAMESPACE = "node:";
const NPM_BUILTIN_NAMESPACE = "npm:";
const BUN_BUILTIN_NAMESPACE = "bun:";
const nodeBuiltins = builtinModules.filter((id) => !id.includes(":"));
const { bun: isBun, deno: isDeno } = process.versions;
function isBuiltin(id) {
	if (isDeno && id.startsWith(NPM_BUILTIN_NAMESPACE)) return true;
	if (isBun && id.startsWith(BUN_BUILTIN_NAMESPACE)) return true;
	return isNodeBuiltin(id);
}
function isNodeBuiltin(id) {
	if (id.startsWith(NODE_BUILTIN_NAMESPACE)) return true;
	return nodeBuiltins.includes(id);
}
const browserExternalId = "__vite-browser-external";
const browserExternalLength = 24;
function isBrowserExternal(id) {
	return id.startsWith(browserExternalId);
}
function toBuiltin(id) {
	if (id.startsWith(browserExternalId)) id = id.slice(browserExternalLength);
	if (id.startsWith(NPM_BUILTIN_NAMESPACE) || id.startsWith(BUN_BUILTIN_NAMESPACE) || id.startsWith(NODE_BUILTIN_NAMESPACE)) return id;
	if (isDeno || isBun) return id;
	return `node:${id}`;
}
export { isBrowserExternal as a, isBuiltin as i, toBuiltin as t };

//# sourceMappingURL=owner-12.mjs.map