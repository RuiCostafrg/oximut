import "./shared-CPxUEhZH.mjs";
// node_modules/vitest/dist/chunks/constants.DLYM6cZY.js
globalThis.__sharedEvaluations ??= {};
globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/constants.DLYM6cZY.js"] = (globalThis.__sharedEvaluations["file:///root/.t3/worktrees/oximut/t3-ca3d9bc2-fcbfe41eae6056ad/node_modules/vitest/dist/chunks/constants.DLYM6cZY.js"] || 0) + 1;
const defaultPort = 51204;
const defaultBrowserPort = 23315;
const defaultInspectPort = 9229;
const API_PATH = "/__vitest_api__";
const CONFIG_NAMES = ["vitest.config", "vite.config"];
const CONFIG_EXTENSIONS = [
	".ts",
	".mts",
	".cts",
	".js",
	".mjs",
	".cjs"
];
const configFiles = CONFIG_NAMES.flatMap((name) => CONFIG_EXTENSIONS.map((ext) => name + ext));
const globalApis = [
	"suite",
	"test",
	"describe",
	"it",
	"chai",
	"expect",
	"assert",
	"expectTypeOf",
	"assertType",
	"vitest",
	"vi",
	"beforeAll",
	"afterAll",
	"beforeEach",
	"afterEach",
	"onTestFinished",
	"onTestFailed",
	"aroundEach",
	"aroundAll"
];
export { API_PATH as A, defaultPort as a, defaultInspectPort as b, configFiles as c, defaultBrowserPort as d, globalApis as g };

//# sourceMappingURL=owner-2.mjs.map